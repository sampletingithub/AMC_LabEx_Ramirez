
import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: require('./assets/just_in.jpg'),
    name: 'Justin P. Ramirez',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Kapitbahayan Elementary School',
      elementaryYear: '2010',
      highSchool: 'Kaunlaran High School',
      highSchoolYear: '2013',
      college: 'Global Reciprocal Colleges',
      collegeYear: '2024',
    },

    about: `I am a currently pursuing a  Bachelor  of Science in Information Technology  in Global Reciprocal Colleges. I am a  youngest in our family and I have a twin but he is not here, he is living in bulacan in my auntie.  My hobbies are playing  mobile legends bang bang, badminton, also basketball, actually I am a player of BSIT now. My first course that I want is Marine and second option is BSIT.`,
   
   
    projects:
      {
        projectName: 'Tree planting',
        imageSrc: 'https://scontent.fmnl9-1.fna.fbcdn.net/v/t39.30808-6/376889259_699671392199670_2960027847947950187_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=3635dc&_nc_eui2=AeEyxslPlBdq3pJNDPhf1k7fpwW9kON5lTSnBb2Q43mVNBnb15BS0n-wmvOOl5g9GIdY43aBfPdn1XptZcnhPojx&_nc_ohc=VHw8ZYG2IBoAX8fVmEL&_nc_ht=scontent.fmnl9-1.fna&oh=00_AfDhhIsZEL4TDjCUnK3hCFIsJqstqrWUm8KUD2Bmj3GIew&oe=65D9ED0C',       
        description: 'Tree planting is the deliberate act of placing tree seedlings into the ground to enhance environmental sustainability',
      },



    contact: {
      mobile: '09955260148', // Replace with your actual mobile phone number
      email: 'ramirezjustin340@gmail.com', // Replace with your actual email address
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects'; // Move to the 'projects' section
      case 'projects':
          return 'contact'; // Move to the 'contact' section
        case 'contact':
          return 'name'; // Loop back to the start
        default:
          return 'name';
    }
  });
};

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
           
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 35,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 20,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 300,
    height: 300,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 16,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;
